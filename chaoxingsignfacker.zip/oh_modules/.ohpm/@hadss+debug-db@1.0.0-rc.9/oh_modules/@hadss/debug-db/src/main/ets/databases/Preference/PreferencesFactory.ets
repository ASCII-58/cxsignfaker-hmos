/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Preferences } from './Preferences';
import dataPreferences from '@ohos.data.preferences';
import Logger from '../../utils/Logger';
import CommonConstants from '../../constants/CommonConstants';

export class PreferencesFactory {
  public async createPreferences(context: Context, preferencesName: string,
    customPreferenceOptions?: dataPreferences.Options): Promise<Preferences | undefined> {
    const preferenceOptions: dataPreferences.Options = customPreferenceOptions ?? {
      name: preferencesName
    };
    try {
      let preferencesInstance = await dataPreferences.getPreferences(context, preferenceOptions)
      let preferences = new Preferences(preferencesInstance);
      Logger.info(CommonConstants.TAG_PREFERENCE, `Get Preferences successfully`);
      return preferences;
    } catch (err) {
      Logger.error(CommonConstants.TAG_PREFERENCE, `Get Preferences failed, code is ${err.code}, message is ${err.message}`);
      return;
    }
  }

  public async deletePreferences(context: Context, preferencesName: string): Promise<boolean> {
    try {
      await dataPreferences.deletePreferences(context, preferencesName);
      return true;
    } catch (err) {
      Logger.info(CommonConstants.TAG_PREFERENCE, `Delete Preferences successfully`)
      return false;
    }
  }
}