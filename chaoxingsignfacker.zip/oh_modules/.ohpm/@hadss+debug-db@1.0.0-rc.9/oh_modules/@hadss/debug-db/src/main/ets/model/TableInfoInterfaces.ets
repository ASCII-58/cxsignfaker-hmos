/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { preferences, relationalStore } from '@kit.ArkData';

export type rdbStoreValueType = relationalStore.ValueType | undefined;

export type preferencesValueType = preferences.ValueType | undefined;

export type CommonValueType = preferences.ValueType | undefined;

export type kvStoreValueType = string | number | boolean | Uint8Array | undefined;

export interface CommonColumnData {
  dataType: string;
  value: CommonValueType;
}

export interface RdbStoreColumnData {
  dataType: string;
  value: rdbStoreValueType;
}

export interface preferenceColumnData {
  dataType: string;
  value: preferencesValueType;
}

export interface KVStoreColumnData {
  dataType: string;
  value: kvStoreValueType;
}

export interface RowDataRequest {
  title: string;
  isPrimary: boolean;
  dataType: string;
  value: string;
}

export interface TableInfo {
  title: string;
  isPrimary: boolean;
}