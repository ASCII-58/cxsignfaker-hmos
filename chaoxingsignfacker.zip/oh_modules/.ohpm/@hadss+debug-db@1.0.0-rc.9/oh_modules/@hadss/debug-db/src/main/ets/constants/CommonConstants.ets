/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Common constants for all files.
 */
export default class CommonConstants {
  /**
   * The debugDB tag
   */
  static readonly TAG_DEBUG_DB: string = 'DebugDB';
  /**
   * The server tag
   */
  static readonly TAG_SERVER: string = 'AppServer';
  /**
   * The RdbStore tag
   */
  static readonly TAG_RDB_STORE: string = 'RdbStore';
  /**
   * The Preferences tag
   */
  static readonly TAG_PREFERENCE: string = 'Preferences';
  /**
   * The KVStore tag
   */
  static readonly TAG_KV_STORE: string = 'KVStore';
  static readonly TAG_APP_STORAGE: string = 'AppStorage';
  /**
   * The server port
   */
  static readonly SERVER_PORT: number = 8080;
  /**
   * The static extensions
   */
  static readonly STATIC_EXTENSIONS = ['.html', '.css', '.js', '.png', '.jpg', '.jpeg', '.gif', '.ico', '.svg'];
  /**
   * The app preferences
   */
  static readonly ALL_PREFERENCES = 'ALL_PREFERENCES';
  /**
   * The app kvStore
   */
  static readonly ALL_KV_STORE = 'ALL_KV_STORE';
  static readonly ALL_APP_STORAGE = 'ALL_AppStorage';
  static readonly APP_STORAGE = 'AppStorage';
  /**
   * The constant 'Key'
   */
  static readonly KEY = 'Key';
  /**
   * The constant 'Value'
   */
  static readonly VALUE = 'Value';
  /**
   * The primary key of table
   */
  static readonly PK = 'pk';
  /**
   * The normal key of table
   */
  static readonly NAME = 'name';
  static readonly APP_PREFIX = 'APP__';
}