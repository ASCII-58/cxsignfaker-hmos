/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { distributedKVStore } from '@kit.ArkData';
import { KVStore } from '../databases/KVStore/KVStore';
import { TableDataResponse, UpdateRowResponse } from '../model/ResponseInterfaces';
import { KVStoreColumnData, RowDataRequest, TableInfo, kvStoreValueType } from '../model/TableInfoInterfaces';
import Logger from './Logger';
import CommonConstants from '../constants/CommonConstants';
import DataTypeConstants from '../constants/DataTypeConstants';

export class KVStoreHelper {
  public static async getAllKVStoreName(kvManager: distributedKVStore.KVManager, bundleName: string): Promise<string[] | undefined> {
    try {
      let allKVStoreId = await kvManager.getAllKVStoreId(bundleName);
      return allKVStoreId;
    } catch (err) {
      Logger.error(CommonConstants.TAG_KV_STORE, `Failed to get ALLKVStoreId, code is ${err.code}, message is ${err.message}`);
      return;
    }
  }

  public static async getKVStoreData(kvStore: KVStore): Promise<TableDataResponse> {
    let tableDataResponse: TableDataResponse = {
      tableInfos: undefined,
      rows: undefined,
      isSuccessful: true,
      errorMessage: '',
      isEditable: true,
      isSelectQuery: true
    };
    let keyInfo: TableInfo = {
      title: CommonConstants.KEY,
      isPrimary: true
    };
    let valueInfo: TableInfo = {
      title: CommonConstants.VALUE,
      isPrimary: false
    };
    tableDataResponse.tableInfos = new Array<TableInfo>();
    tableDataResponse.tableInfos.push(keyInfo);
    tableDataResponse.tableInfos.push(valueInfo);
    tableDataResponse.rows = new Array();
    if (kvStore !== undefined) {
      try {
        let entries = await kvStore.getEntries(' ');
        for (let entry of entries) {
          let row = new Array<KVStoreColumnData>();
          let key = entry.key;
          let KeyColumnData: KVStoreColumnData = {
            dataType: DataTypeConstants.TEXT,
            value: key
          };
          row.push(KeyColumnData);
          let valueColumnData: KVStoreColumnData = {
            dataType: '',
            value: undefined
          };
          let value = entry.value;
          valueColumnData.value = value.value.toString();
          switch (value.type.toString().toLowerCase()) {
            case DataTypeConstants.BOOLEAN:
              valueColumnData.dataType = DataTypeConstants.BOOLEAN;
              break;
            case DataTypeConstants.INTEGER:
              valueColumnData.dataType = DataTypeConstants.INTEGER;
              break;
            case DataTypeConstants.FLOAT:
            case DataTypeConstants.DOUBLE:
              valueColumnData.dataType = DataTypeConstants.REAL;
              break;
            default:
              valueColumnData.dataType = DataTypeConstants.TEXT;
              break;
          }
          row.push(valueColumnData);
          tableDataResponse.rows.push(row);
        }
      } catch (err) {
        tableDataResponse.isSuccessful = false;
        tableDataResponse.errorMessage = err.message;
      }
    }
    return tableDataResponse;
  }

  public static async addOrUpdateRow(kvStore: KVStore, rowDataRequests: Array<RowDataRequest>): Promise<UpdateRowResponse> {
    let updateRowResponse: UpdateRowResponse = {
      isSuccessful: false
    };
    if (kvStore === undefined || rowDataRequests === undefined) {
      return updateRowResponse;
    }
    let key = rowDataRequests[0].value as string | undefined;
    let value = rowDataRequests[1].value as kvStoreValueType;

    if (key !== undefined && value !== undefined) {
      try {
        await kvStore.put(key, value);
        updateRowResponse.isSuccessful = true;
      } catch (err) {
        Logger.error(CommonConstants.TAG_KV_STORE, `Add or update failed, code is ${err.code}, message is ${err.message}`);
      }
    }
    return updateRowResponse;
  }


  public static async deleteRow(kvStore: KVStore, rowDataRequests: Array<RowDataRequest>): Promise<UpdateRowResponse> {
    let updateRowResponse: UpdateRowResponse = {
      isSuccessful: false
    };
    if (kvStore === undefined || rowDataRequests === undefined) {
      return updateRowResponse;
    }
    let key = rowDataRequests[0].value as string | undefined;
    if (key !== undefined) {
      try {
        await kvStore.delete(key);
        updateRowResponse.isSuccessful = true;
      } catch (err) {
        Logger.error(CommonConstants.TAG_KV_STORE, `Delete failed, code is ${err.code}, message is ${err.message}`);
      }
    }
    return updateRowResponse;
  }
}