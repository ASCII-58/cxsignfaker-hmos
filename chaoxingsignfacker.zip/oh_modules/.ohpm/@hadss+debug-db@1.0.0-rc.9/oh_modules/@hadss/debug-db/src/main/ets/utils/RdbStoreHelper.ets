/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { RdbStore } from '../databases/RdbStore/RdbStore';
import { relationalStore } from '@kit.ArkData';
import { ReadOptions } from '@kit.CoreFileKit';
import { TableNameParser } from './TableNameParser';
import { TableDataResponse, UpdateRowResponse, Response } from '../model/ResponseInterfaces';
import { RdbStoreColumnData, RowDataRequest, TableInfo } from '../model/TableInfoInterfaces';
import fs from '@ohos.file.fs';
import zlib from '@ohos.zlib';
import Logger from './Logger';
import DataTypeConstants from '../constants/DataTypeConstants';
import CommonConstants from '../constants/CommonConstants';

interface ValueBucketInterface {
  valueBucket: relationalStore.ValuesBucket;
  predicates: relationalStore.RdbPredicates
}

export class RdbStoreHelper {
  public static async getTableData(rdbStore: RdbStore, selectQuery: string, tableName?: string | undefined): Promise<TableDataResponse> {
    let tableDataResponse: TableDataResponse = {
      tableInfos: undefined,
      rows: undefined,
      isSuccessful: false,
      errorMessage: '',
      isEditable: false,
      isSelectQuery: false,
    };

    tableDataResponse.isSelectQuery = true;
    let tablesInfos: Array<TableInfo> | undefined;
    let quotedTableName: string = '';

    // Extract the table name from the query statement
    if (tableName === undefined) {
      tableName = RdbStoreHelper.getTableName(selectQuery);
    }

    if (tableName !== undefined) {
      quotedTableName = RdbStoreHelper.getQuoted(tableName);
      const pragmaQuery = `PRAGMA table_info(${quotedTableName})`;
      tablesInfos = await RdbStoreHelper.getTableInfo(rdbStore, pragmaQuery);
      if (tablesInfos !== undefined) {
        tableDataResponse.tableInfos = tablesInfos;
      }
    }

    // Check the type of table
    let isView = false;
    let resultSet: relationalStore.ResultSet | undefined;
    if (rdbStore !== undefined) {
      try {
        resultSet = await rdbStore.querySql(`SELECT type FROM sqlite_master WHERE name=?`, [quotedTableName]);
        if (resultSet !== undefined && resultSet.goToFirstRow()) {
          isView = resultSet.getString(0).toLowerCase() === 'view';
          resultSet.close();
        }
      } catch (err) {
        Logger.error(CommonConstants.TAG_RDB_STORE, `Query failed, code is ${err.code}, message is ${err.message}`);
      }
    }

    tableDataResponse.isEditable = tableName !== undefined && tableDataResponse.tableInfos !== undefined && !isView;

    // Execute sql query and process the result
    if (rdbStore !== undefined) {
      try {
        resultSet = await rdbStore.querySql(selectQuery);
      } catch (err) {
        tableDataResponse.isSuccessful = false;
        tableDataResponse.errorMessage = err.message;
        Logger.error(CommonConstants.TAG_RDB_STORE, `Query failed, code is ${err.code}, message is ${err.message}`);
        return tableDataResponse;
      }
    }

    if (resultSet !== undefined) {
      try {
        resultSet.goToFirstRow();
        if (tableDataResponse.tableInfos === undefined) {
          tableDataResponse.tableInfos = new Array<TableInfo>();
          for (let i = 0; i < resultSet.columnCount; i++) {
            let tableInfo: TableInfo = {
              title: '',
              isPrimary: false
            };
            tableInfo.title = resultSet.getColumnName(i);
            tableInfo.isPrimary = true;
            tableDataResponse.tableInfos.push(tableInfo);
          }
        }

        tableDataResponse.isSuccessful = true;
        tableDataResponse.rows = new Array();
        let columnNames = resultSet.columnNames as string[];
        let tableInfosModified = new Array<TableInfo>();

        for (let columnName of columnNames) {
          for (let tableInfo of tableDataResponse.tableInfos) {
            if (columnName === tableInfo.title) {
              tableInfosModified.push(tableInfo);
              break;
            }
          }
        }

        if (tableDataResponse.tableInfos.length !== tableInfosModified.length) {
          tableDataResponse.tableInfos = tableInfosModified;
          tableDataResponse.isEditable = false;
        }

        if (resultSet.rowCount > 0) {
          if (resultSet.goToFirstRow()) {
            do {
              let tableData = new Array<RdbStoreColumnData>();
              for (let i = 0; i < resultSet.columnCount; i++) {
                let columnData: RdbStoreColumnData = {
                  dataType: '',
                  value: undefined
                };
                let value = resultSet.getValue(i);
                switch (typeof value) {
                  case DataTypeConstants.BIGINT:
                    columnData.dataType = DataTypeConstants.TEXT;
                    columnData.value = value?.toString();
                    break;
                  case DataTypeConstants.NUMBER:
                    if (Number.isInteger(value)) {
                      columnData.dataType = DataTypeConstants.INTEGER;
                    } else {
                      columnData.dataType = DataTypeConstants.REAL;
                    }
                    columnData.value = value;
                    break;
                  case DataTypeConstants.STRING:
                  case DataTypeConstants.FUNCTION:
                    columnData.dataType = DataTypeConstants.TEXT;
                    columnData.value = value;
                    break;
                  default:
                    if (value instanceof Uint8Array) {
                      columnData.dataType = DataTypeConstants.BLOB;
                      columnData.value = value.toString();
                    } else {
                      columnData.dataType = DataTypeConstants.TEXT;
                      columnData.value = JSON.stringify(value);
                    }
                }
                tableData.push(columnData);
              }
              tableDataResponse.rows.push(tableData);
            } while (resultSet.goToNextRow())
          }
          resultSet.close();
          return tableDataResponse;
        }
      } catch (err) {
        tableDataResponse.isSuccessful = false;
        tableDataResponse.errorMessage = err.message;
      }
    } else {
      tableDataResponse.isSuccessful = false;
      tableDataResponse.errorMessage = 'ResultSet is null';
    }
    return tableDataResponse;
  }

  public static async getTableInfo(rdbStore: RdbStore, pragmaQuery: string): Promise<TableInfo[] | undefined> {
    let resultSet: relationalStore.ResultSet;
    try {
      resultSet = await rdbStore.querySql(pragmaQuery);
    } catch (err) {
      Logger.error(CommonConstants.TAG_DEBUG_DB, `Query failed, code is ${err.code}, message is ${err.message}`);
      return;
    }
    if (resultSet !== undefined) {
      let tableInfos = new Array<TableInfo>();
      if (resultSet.rowCount > 0) {
        while (resultSet.goToNextRow()) {
          let tableInfo: TableInfo = {
            title: '',
            isPrimary: false
          };
          for (let i = 0; i < resultSet.columnCount; i++) {
            let columnName = resultSet.getColumnName(i);
            switch (columnName) {
              case CommonConstants.PK:
                tableInfo.isPrimary = resultSet.getLong(i) === 1;
                break;
              case CommonConstants.NAME:
                tableInfo.title = resultSet.getString(i);
                break;
              default:
            }
          }
          tableInfos.push(tableInfo);
        }
      }
      resultSet.close();
      return tableInfos;
    }
    return;
  }

  public static async getAllTableName(rdbStore: RdbStore): Promise<Response> {
    let response: Response = {
      rows: [],
      columns: [],
      isSuccessful: false,
      error: '',
      dbVersion: 0
    };
    let resultSet: relationalStore.ResultSet;
    try {
      resultSet = await rdbStore.querySql(`SELECT name FROM sqlite_master WHERE type='table' OR type='view' ORDER BY name COLLATE NOCASE`);
      if (resultSet.rowCount > 0) {
        while (resultSet.goToNextRow()) {
          response.rows.push(resultSet.getString(0));
        }
        response.isSuccessful = true;
        response.dbVersion = rdbStore.getVersion();
        resultSet.close();
      }
    } catch (err) {
      Logger.error(CommonConstants.TAG_RDB_STORE, `Query failed, code is ${err.code}, message is ${err.message}`);
    }
    return response
  }

  public static async addRow(rdbStore: RdbStore, tableName: string, rowDataRequests: Array<RowDataRequest>): Promise<UpdateRowResponse> {
    let updateRowResponse: UpdateRowResponse = {
      isSuccessful: false
    };
    if (tableName === undefined || rowDataRequests === undefined) {
      return updateRowResponse;
    }
    let result = RdbStoreHelper.getValueBucket(tableName, rowDataRequests) as ValueBucketInterface;
    let effectedRows: number = 0;
    try {
      effectedRows = await rdbStore.insert(tableName, result.valueBucket);
    } catch (err) {
      Logger.error(CommonConstants.TAG_RDB_STORE, `Add failed, code is ${err.code}, message is ${err.message}`);
    }
    updateRowResponse.isSuccessful = effectedRows > 0;
    return updateRowResponse;
  }

  public static async updateRow(rdbStore: RdbStore, tableName: string, rowDataRequests: Array<RowDataRequest>): Promise<UpdateRowResponse> {
    let updateRowResponse: UpdateRowResponse = {
      isSuccessful: false
    }
    if (tableName === undefined || rowDataRequests === undefined) {
      return updateRowResponse;
    }
    let result = RdbStoreHelper.getValueBucket(tableName, rowDataRequests) as ValueBucketInterface;
    let effectedRows: number = 0;
    try {
      effectedRows = await rdbStore.update(result.valueBucket, result.predicates);
    } catch (err) {
      Logger.error(CommonConstants.TAG_RDB_STORE, `Update failed, code is ${err.code}, message is ${err.message}`);
    }
    updateRowResponse.isSuccessful = effectedRows > 0;
    return updateRowResponse;
  }

  public static async deleteRow(rdbStore: RdbStore, tableName: string, rowDataRequests: Array<RowDataRequest>): Promise<UpdateRowResponse> {
    let updateRowResponse: UpdateRowResponse = {
      isSuccessful: false
    };
    if (tableName === undefined || rowDataRequests === undefined) {
      return updateRowResponse;
    }
    let predicates = new relationalStore.RdbPredicates(tableName);

    for (let rowDataRequest of rowDataRequests) {
      if (rowDataRequest.isPrimary) {
        predicates.equalTo(rowDataRequest.title, rowDataRequest.value);
      }
    }
    let effectedRows: number = 0;
    try {
      effectedRows = await rdbStore.delete(predicates);
    } catch (err) {
      Logger.error(CommonConstants.TAG_RDB_STORE, `Delete failed, code is ${err.code}, message is ${err.message}`);
    }
    updateRowResponse.isSuccessful = effectedRows > 0;
    return updateRowResponse;
  }

  public static async exec(rdbStore: RdbStore, sql: string): Promise<TableDataResponse> {
    let tableDataResponse: TableDataResponse = {
      tableInfos: undefined,
      rows: undefined,
      isSuccessful: false,
      errorMessage: '',
      isEditable: false,
      isSelectQuery: false
    };
    try {
      let tableName = RdbStoreHelper.getTableName(sql);
      if (tableName !== undefined && tableName.trim() !== '') {
        let quotedTableName = RdbStoreHelper.getQuoted(tableName);
        sql = sql.replace(tableName, quotedTableName);
      }
      await rdbStore.execSql(sql);
    } catch (err) {
      Logger.error(CommonConstants.TAG_RDB_STORE, `SQL exec failed, code is ${err.code}, message is ${err.message}`)
      tableDataResponse.errorMessage = err.message;
      return tableDataResponse;
    }
    tableDataResponse.isSuccessful = true;
    return tableDataResponse;
  }

  public static async getRdbStoreNames(context: Context): Promise<string[]> {
    let databaseDirPath = `${context.databaseDir}/rdb`;
    let rdbStoreFilenames: string[] = [];
    let rdbStoreNames: string[] = [];
    if (!fs.accessSync(databaseDirPath)) {
      Logger.info(CommonConstants.TAG_RDB_STORE, `Failed to get rdbStore names, rdbStore directory is empty`);
      return [];
    }
    try {
      rdbStoreFilenames = await fs.listFile(databaseDirPath);
      rdbStoreNames = RdbStoreHelper.filterRdbStoresFilenames(rdbStoreFilenames);
    } catch (err) {
      Logger.error(CommonConstants.TAG_RDB_STORE, `Failed to get rdbStore names, code is ${err.code}, message is ${err.message}`);
    }
    return rdbStoreNames;
  }

  public static async getEncryptedRdbStoreNames(context: Context): Promise<string[]> {
    let encryptedDatabaseDirPath = `${context.databaseDir}/rdb/key`;
    let encryptedRdbStoreFilenames: string[] = [];
    let encryptedRdbStoreNames: string[] = [];
    if (!fs.accessSync(encryptedDatabaseDirPath)) {
      Logger.info(CommonConstants.TAG_RDB_STORE, `Failed to get rdbStore names, rdbStore directory is empty`);
      return [];
    }
    try {
      encryptedRdbStoreFilenames = await fs.listFile(encryptedDatabaseDirPath);
      encryptedRdbStoreNames = RdbStoreHelper.mapEncryptedRdbStoresFilenames(encryptedRdbStoreFilenames)
    } catch (err) {
      Logger.error(CommonConstants.TAG_RDB_STORE, `Failed to get encrypted rdbStore names, code is ${err.code}, message is ${err.message}`);
    }
    return encryptedRdbStoreNames;
  }

  public static async getRdbStoreFile(context: Context, rdbStoreName: string): Promise<Uint8Array> {
    let databaseDirPath = `${context.databaseDir}/rdb`;
    let tempDirPath = `${context.tempDir}/${rdbStoreName}`;
    let filePath = `${databaseDirPath}/${rdbStoreName}`;
    let sourceFilesPath = [filePath, `${filePath}-wal`, `${filePath}-shm`];
    let zipFilePath = `${tempDirPath}/${rdbStoreName}.zip`;

    // Check and create a temporary zip file
    if (!fs.accessSync(tempDirPath)) {
      try {
        fs.mkdir(tempDirPath);
      } catch (err) {
        Logger.error(CommonConstants.TAG_RDB_STORE, `Failed to create temporary directory, code is ${err.code}, message is ${err.message}`);
      }
    } else {
      fs.rmdir(tempDirPath);
    }
    await RdbStoreHelper.compressFiles(sourceFilesPath, tempDirPath, zipFilePath);
    let zipFile = await fs.open(zipFilePath, fs.OpenMode.READ_WRITE);
    let fileContent: Uint8Array = new Uint8Array(0);
    try {
      fileContent = await RdbStoreHelper.getFileUint8Array(zipFile);
    } catch (err) {
      Logger.error(CommonConstants.TAG_RDB_STORE, `Failed to get the byte stream, code is ${err.code}, message is ${err.message}`);
    } finally {
      if (fs.accessSync(tempDirPath)) {
        fs.rmdir(tempDirPath);
      }
    }
    return fileContent;
  }

  public static async getFileUint8Array(file: fs.File): Promise<Uint8Array> {
    let bufSize = 4096;
    let readSize = 0;
    let buf = new ArrayBuffer(bufSize);
    let totalBuf = new ArrayBuffer(0);
    let readOptions: ReadOptions = {
      offset: readSize,
      length: bufSize
    };
    let readLen = await fs.read(file.fd, buf, readOptions);
    while (readLen > 0) {
      readSize += readLen;
      let tempBuf = new ArrayBuffer(totalBuf.byteLength + readLen);
      new Uint8Array(tempBuf).set(new Uint8Array(totalBuf), 0);
      new Uint8Array(tempBuf).set(new Uint8Array(buf, 0, readLen), totalBuf.byteLength);
      totalBuf = tempBuf;
      readOptions.offset = readSize;
      readLen = await fs.read(file.fd, buf, readOptions);
    }
    await fs.close(file);
    return new Uint8Array(totalBuf);
  }

  public static async compressFiles(filesPath: string[], tempDirPath: string, zipPath: string): Promise<void> {
    for (let path of filesPath) {
      let fileName = path.split('/').pop() as string;
      await fs.copyFile(path, `${tempDirPath}/${fileName}`);
    }
    let options: zlib.Options = {
      level: zlib.CompressLevel.COMPRESS_LEVEL_DEFAULT_COMPRESSION,
      memLevel: zlib.MemLevel.MEM_LEVEL_DEFAULT,
      strategy: zlib.CompressStrategy.COMPRESS_STRATEGY_DEFAULT_STRATEGY
    };
    try {
      await zlib.compressFile(tempDirPath, zipPath, options);
    } catch (err) {
      Logger.error(CommonConstants.TAG_RDB_STORE, `Failed to compress files, code is ${err.code}, message is ${err.message}`);
    }
  }

  public static getTableName(selectQuery: string): string | undefined {
    const tableNameParser: TableNameParser = new TableNameParser(selectQuery);
    let tableNames = tableNameParser.getTables() as Set<string>;
    for (let tableName of tableNames) {
      if (tableName !== '') {
        return tableName;
      }
    }
    return;
  }

  public static getValueBucket(tableName: string, rowDataRequests: Array<RowDataRequest>) {
    let valueBucket: relationalStore.ValuesBucket = {};
    let predicates = new relationalStore.RdbPredicates(tableName);
    for (let rowDataRequest of rowDataRequests) {
      let value = rowDataRequest.value;
      let title = rowDataRequest.title
      switch (rowDataRequest.dataType) {
        case DataTypeConstants.NUMBER:
        case DataTypeConstants.NUM:
        case DataTypeConstants.REAL:
          if (RdbStoreHelper.checkIfBigInt(value)) {
            valueBucket[title] = BigInt(value);
          } else {
            valueBucket[title] = Number(value);
          }
          break;
        case DataTypeConstants.NUM_FMT:
          valueBucket[title] = RdbStoreHelper.convertStringToUint8Array(value);
          break;
        case DataTypeConstants.STRING:
        case DataTypeConstants.TEXT:
          valueBucket[title] = value;
          break;
        default:
          valueBucket[title] = value;
      }
      if (rowDataRequest.isPrimary) {
        predicates.equalTo(title, value);
      }
    }
    return ({
      valueBucket: valueBucket,
      predicates: predicates
    } as ValueBucketInterface)
  }

  public static filterRdbStoresFilenames(files: string[]): string[] {
    return files.filter((fileName) => {
      if (fileName.endsWith('.db')) {
        return true;
      }
      return false;
    })
  }

  public static mapEncryptedRdbStoresFilenames(files: string[]): string[] {
    return files.map((fileName) => {
      const baseName = fileName.substring(0, fileName.lastIndexOf('.'));
      return `${baseName}.db`;
    });
  }

  public static checkIfBigInt(str: string): boolean {
    try {
      let bigIntValue = BigInt(str);
      return bigIntValue > BigInt(Number.MAX_SAFE_INTEGER);
    } catch (e) {
      return false;
    }
  }

  public static convertStringToUint8Array(str: string): Uint8Array {
    if (!str || typeof str !== 'string') {
      return new Uint8Array();
    }
    let parts = str.split(',');
    let numArray = parts.map(part => {
      let num = Number(part.trim());
      return isNaN(num) ? null : num;
    })
    if (numArray.some(num => num === null)) {
      return new Uint8Array();
    }
    return new Uint8Array(numArray as number[]);
  }

  public static getQuoted(str: string): string {
    return `[${str}]`;
  }
}

