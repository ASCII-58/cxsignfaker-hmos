/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Preferences } from '../databases/Preference/Preferences';
import { TableDataResponse, UpdateRowResponse } from '../model/ResponseInterfaces';
import { preferenceColumnData, RowDataRequest, TableInfo, preferencesValueType } from '../model/TableInfoInterfaces';
import Logger from './Logger';
import fs from '@ohos.file.fs';
import DataTypeConstants from '../constants/DataTypeConstants';
import CommonConstants from '../constants/CommonConstants';

export class PreferencesHelper {
  public static getAllPreferencesName(context: Context): string[] {
    let preferencesDir = context.preferencesDir;
    let preferencesNames: string[] = [];
    try {
      preferencesNames = fs.listFileSync(preferencesDir);
    } catch (err) {
      Logger.error(CommonConstants.TAG_RDB_STORE, `Failed to get prferences names`);
    }
    preferencesNames.sort();
    return preferencesNames;
  }

  public static async getPreferencesData(preferences: Preferences): Promise<TableDataResponse> {
    let tableDataResponse: TableDataResponse = {
      tableInfos: undefined,
      rows: undefined,
      isSuccessful: true,
      errorMessage: '',
      isEditable: true,
      isSelectQuery: true
    };
    let keyInfo: TableInfo = {
      title: CommonConstants.KEY,
      isPrimary: true
    };
    let valueInfo: TableInfo = {
      title: CommonConstants.VALUE,
      isPrimary: false
    };
    tableDataResponse.tableInfos = new Array<TableInfo>();
    tableDataResponse.tableInfos.push(keyInfo);
    tableDataResponse.tableInfos.push(valueInfo);
    tableDataResponse.rows = new Array();
    if (preferences !== undefined) {
      try {
        let object = await preferences.getAll();
        let allKeys = Object.keys(object) as string[];
        for (let key of allKeys) {
          let row = new Array<preferenceColumnData>();
          let KeyColumnData: preferenceColumnData = {
            dataType: DataTypeConstants.TEXT,
            value: key
          };
          row.push(KeyColumnData);
          let valueColumnData: preferenceColumnData = {
            dataType: '',
            value: undefined
          };
          let value = Object(object)[key] as preferencesValueType;
          if (value !== undefined && value !== null) {
            valueColumnData.value = value.toString();
            switch (typeof value) {
              case DataTypeConstants.BOOLEAN:
                valueColumnData.dataType = DataTypeConstants.BOOLEAN;
                break;
              case DataTypeConstants.NUMBER:
                if (Number.isInteger(value)) {
                  valueColumnData.dataType = DataTypeConstants.INTEGER;
                } else {
                  valueColumnData.dataType = DataTypeConstants.REAL;
                }
                break;
              case DataTypeConstants.STRING:
                valueColumnData.dataType = DataTypeConstants.TEXT;
                break;
              default:
                valueColumnData.dataType = DataTypeConstants.TEXT;
            }
          }
          row.push(valueColumnData);
          tableDataResponse.rows.push(row);
        }
      } catch (err) {
        Logger.error(CommonConstants.TAG_PREFERENCE, `Get preferences data failed, code is ${err.code}, message is ${err.message}`);
        tableDataResponse.errorMessage = err.message;
        tableDataResponse.isSuccessful = false;
      }

    }
    return tableDataResponse;
  }

  public static async addOrUpdateRow(preferences: Preferences, rowDataRequests: Array<RowDataRequest>): Promise<UpdateRowResponse> {
    let updateRowResponse: UpdateRowResponse = {
      isSuccessful: false
    };
    if (preferences === undefined || rowDataRequests === undefined) {
      return updateRowResponse;
    }
    let key = rowDataRequests[0].value as string | undefined;
    let value = rowDataRequests[1].value as preferencesValueType;

    if (key !== undefined && value !== undefined) {
      try {
        await preferences.put(key, value);
        await preferences.flush();
        updateRowResponse.isSuccessful = true;
      } catch (err) {
        Logger.error(CommonConstants.TAG_PREFERENCE, `Add or update failed, code is ${err.code}, message is ${err.message}`);
      }
    }
    return updateRowResponse;
  }

  public static async deleteRow(preferences: Preferences, rowDataRequests: Array<RowDataRequest>): Promise<UpdateRowResponse> {
    let updateRowResponse: UpdateRowResponse = {
      isSuccessful: false
    };
    if (preferences === undefined || rowDataRequests === undefined) {
      return updateRowResponse;
    }
    let key = rowDataRequests[0].value as string | undefined;
    if (key !== undefined) {
      try {
        await preferences.delete(key);
        await preferences.flush();
        updateRowResponse.isSuccessful = true;
      } catch (err) {
        Logger.error(CommonConstants.TAG_PREFERENCE, `Delete failed, code is ${err.code}, message is ${err.message}`);
      }
    }
    return updateRowResponse;
  }
}