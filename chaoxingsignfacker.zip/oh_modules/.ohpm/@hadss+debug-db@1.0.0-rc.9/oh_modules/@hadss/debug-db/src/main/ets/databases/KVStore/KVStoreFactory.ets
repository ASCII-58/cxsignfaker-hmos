/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { distributedKVStore } from '@kit.ArkData';
import { KVStore } from './KVStore';
import Logger from '../../utils/Logger';
import CommonConstants from '../../constants/CommonConstants';


export class KVStoreFactory {
  public static async getKVStore(kvManager: distributedKVStore.KVManager, storeId: string, isEncrypted: boolean,
    customStoreOptions?: distributedKVStore.Options): Promise<KVStore | undefined> {
    const kvStoreOptions: distributedKVStore.Options = customStoreOptions ?? {
      createIfMissing: true,
      encrypt: isEncrypted,
      backup: false,
      autoSync: false,
      kvStoreType: distributedKVStore.KVStoreType.SINGLE_VERSION,
      securityLevel: distributedKVStore.SecurityLevel.S1
    };

    try {
      let store = await kvManager.getKVStore<distributedKVStore.SingleKVStore>(storeId, kvStoreOptions);
      let kvStore = new KVStore(store);
      Logger.info(CommonConstants.TAG_KV_STORE, `Get KVStore successfully.`);
      return kvStore
    } catch (err) {
      Logger.error(CommonConstants.TAG_KV_STORE, `Get KVStore failed, code is ${err.code}, message is ${err.message}`);
      return;
    }
  }

  public static async deleteKVStore(kvManager: distributedKVStore.KVManager, bundleName: string, storeId: string): Promise<boolean> {
    try {
      await kvManager.deleteKVStore(bundleName, storeId)
      Logger.info(CommonConstants.TAG_KV_STORE, `Delete KVStore successfully.`)
      return true;
    } catch (err) {
      Logger.error(CommonConstants.TAG_KV_STORE, `Delete KVStore failed, code is ${err.code}, message is ${err.message}`);
      return false;
    }
  }
}