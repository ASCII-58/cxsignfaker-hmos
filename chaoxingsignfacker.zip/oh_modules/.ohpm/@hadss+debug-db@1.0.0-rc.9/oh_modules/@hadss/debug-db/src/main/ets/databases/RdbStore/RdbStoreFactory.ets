/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { RdbStore } from './RdbStore';
import { relationalStore } from '@kit.ArkData';
import Logger from '../../utils/Logger';
import CommonConstants from '../../constants/CommonConstants';

export class RdbStoreFactory {
  public static async createRdbStore(context: Context, rdbStoreName: string, isEncrypted: boolean,
    customDir?: string): Promise<RdbStore | undefined> {
    let rdbName = rdbStoreName;
    if (rdbStoreName.startsWith(CommonConstants.APP_PREFIX)) {
      rdbName = rdbStoreName.substring(CommonConstants.APP_PREFIX.length);
    }
    const storeConfig: relationalStore.StoreConfig = {
      name: rdbName,
      securityLevel: relationalStore.SecurityLevel.S1,
      encrypt: isEncrypted,
      customDir,
    };
    try {
      let rdbStoreInstance = await relationalStore.getRdbStore(context, storeConfig);
      let rdbStore = new RdbStore(rdbStoreInstance);
      Logger.info(CommonConstants.TAG_RDB_STORE, `Get RdbStore successfully`);
      return rdbStore;
    } catch (err) {
      Logger.error(CommonConstants.TAG_RDB_STORE, `Get RdbStore failed, code: ${err.code}, message: ${err.message}`);
      return;
    }
  }

  public static async deleteRdbStore(context: Context, rdbStoreName: string, customDir?: string): Promise<boolean> {
    try {
      const storeConfig: relationalStore.StoreConfig = {
        name: rdbStoreName,
        securityLevel: relationalStore.SecurityLevel.S1,
        // encrypt: isEncrypted,
        customDir,
      };
      await relationalStore.deleteRdbStore(context, storeConfig);
      return true;
    } catch (err) {
      Logger.error(CommonConstants.TAG_RDB_STORE,
        `Delete RdbStore failed, code is ${err.code}, message is ${err.message}`);
      return false;
    }
  }
}