/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { relationalStore, ValueType } from '@kit.ArkData';

/**
 * RdbStore class
 */

export class RdbStore {
  private rdbStore: relationalStore.RdbStore;

  constructor(rdbStore: relationalStore.RdbStore) {
    this.rdbStore = rdbStore;
  }

  public close(): Promise<void> {
    return this.rdbStore.close();
  }

  public delete(predicate: relationalStore.RdbPredicates): Promise<number> {
    return this.rdbStore.delete(predicate);
  }

  public deleteSync(predicate: relationalStore.RdbPredicates): number {
    return this.rdbStore.deleteSync(predicate);
  }

  public insert(tableName: string, values: relationalStore.ValuesBucket, conflict?: relationalStore.ConflictResolution): Promise<number> {
    return this.rdbStore.insert(tableName, values, conflict);
  }

  public insertSync(tableName: string, values: relationalStore.ValuesBucket, conflict?: relationalStore.ConflictResolution): number {
    return this.rdbStore.insertSync(tableName, values, conflict);
  }

  public query(predicate: relationalStore.RdbPredicates, column?: string[] | undefined): relationalStore.ResultSet {
    return this.rdbStore.querySync(predicate, column);
  }

  public querySync(predicate: relationalStore.RdbPredicates, column?: string[] | undefined) {
    return this.rdbStore.query(predicate, column);
  }

  public querySql(sql: string, bindArg?: Array<ValueType>): Promise<relationalStore.ResultSet> {
    return this.rdbStore.querySql(sql, bindArg);
  }

  public querySqlSync(sql: string, bindArg?: Array<ValueType>): relationalStore.ResultSet {
    return this.rdbStore.querySqlSync(sql, bindArg);
  }

  public execSql(sql: string, bindArgs?: relationalStore.ValueType[] | undefined): Promise<void> {
    return this.rdbStore.executeSql(sql, bindArgs);
  }

  public execSqlSync(sql: string, bindArgs?: relationalStore.ValueType[] | undefined) {
    this.rdbStore.executeSync(sql, bindArgs);
  }

  public update(values: relationalStore.ValuesBucket, predicate: relationalStore.RdbPredicates): Promise<number> {
    return this.rdbStore.update(values, predicate);
  }

  public updateSync(predicate: relationalStore.RdbPredicates, values: relationalStore.ValuesBucket): number {
    return this.rdbStore.updateSync(values, predicate);
  }

  public getVersion(): number {
    return this.rdbStore.version;
  }
}