/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Ultra light, Ultra fast parser to extract table name out SQLs, supports oracle dialect SQLs as well.
 *
 * @author Nadeem Mohammad
 * Ref: http://github.com/mnadeem/sql-table-name-parser
 */

export class TableNameParser {
  private readonly NO_INDEX: number = -1;
  private readonly SPACE: string = ' ';
  private readonly REGEX_SPACE: string = '\\s+';
  private readonly TOKEN_ORACLE_HINT_START: string = '/*+';
  private readonly TOKEN_ORACLE_HINT_END: string = '*/';
  private readonly TOKEN_SINGLE_LINE_COMMENT: string = '--';
  private readonly TOKEN_SEMI_COLIN = ';'
  private readonly TOKEN_PARAN_START: string = '(';
  private readonly TOKEN_COMMA: string = ',';
  private readonly TOKEN_SET: string = 'set';
  private readonly TOKEN_OF: string = 'of';
  private readonly TOKEN_DUAL: string = 'dual';
  private readonly TOKEN_DELETE: string = 'delete';
  private readonly TOKEN_CREATE: string = 'create';
  private readonly TOKEN_INDEX: string = 'index';
  private readonly TOKEN_ASTERICK: string = '*';
  private readonly KEYWORD_JOIN: string = 'join';
  private readonly KEYWORD_INTO: string = 'into';
  private readonly KEYWORD_TABLE: string = 'table';
  private readonly KEYWORD_FROM: string = 'from';
  private readonly KEYWORD_USING: string = 'using';
  private readonly KEYWORD_UPDATE: string = 'update';
  private readonly concerned: string[] = [this.KEYWORD_TABLE, this.KEYWORD_INTO, this.KEYWORD_JOIN, this.KEYWORD_USING, this.KEYWORD_UPDATE];
  private readonly ignored: string[] = [this.TOKEN_PARAN_START, this.TOKEN_SET, this.TOKEN_OF, this.TOKEN_DUAL];
  private TOKEN_NEWLINE: string = '\\r\\n|\\r|\\n|\\n\\r';
  private tables = new Map<string, string>();

  constructor(sql: string) {
    const nocomments: string = this.removeComments(sql);
    const normalized: string = this.normalized(nocomments);
    const cleaned: string = this.clean(normalized);
    const tokens: string[] = cleaned.split(this.REGEX_SPACE);
    let index: number = 0;
    let firstToken = tokens[index];
    if (this.isOracleSpecialDelete(firstToken, tokens, index)) {
      this.handleSpecialOracleSpecialDelete(firstToken, tokens, index);
    } else if (this.isCreateIndex(firstToken, tokens, index)) {
      this.handleCreateIndex(firstToken, tokens, index);
    } else {
      while (this.moreTokens(tokens, index)) {
        let currentToken = tokens[index++];
        if (this.isFromToken(currentToken)) {
          this.processFromToken(tokens, index)
        } else if (this.shouldProcess(currentToken)) {
          let nextToken = tokens[index++];
          this.considerInclusion(nextToken);
          if (this.moreTokens(tokens, index)) {
            nextToken = tokens[index++];
          }
        }
      }
    }
  }

  /**
   * Removes single-line comments from the SQL statements.
   * @param sql
   * @returns
   */
  private removeComments(sql: string): string {
    let nextCommentPosition = sql.indexOf(this.TOKEN_SINGLE_LINE_COMMENT);
    while (nextCommentPosition > -1) {
      const end = this.indexOfRegex(this.TOKEN_NEWLINE, sql.substring(nextCommentPosition));
      if (end === 1) {
        return sql.substring(0, nextCommentPosition);
      } else {
        sql = sql.substring(0, nextCommentPosition) + sql.substring(end + nextCommentPosition);
      }
      nextCommentPosition = sql.indexOf(this.TOKEN_SINGLE_LINE_COMMENT);
    }
    return sql;
  }

  /**
   * Finds the position of a regex match within a given string.
   * @param regex
   * @param str
   * @returns
   */
  private indexOfRegex(regex: string, str: string): number {
    const pattern = new RegExp(regex);
    const match = str.match(pattern);
    return match ? match.index ?? -1 : -1;
  }

  /**
   * Normalizes the SQL string.
   * @param sql
   * @returns
   */
  private normalized(sql: string): string {
    let normalized = sql.trim()
      .replace(new RegExp(this.TOKEN_NEWLINE, 'g'), this.SPACE)
      .replace(new RegExp(this.TOKEN_COMMA, 'g'), ' , ')
      .replace(/\(/g, ' ( ')
      .replace(/\)/g, ' ) ');
    if (normalized.endsWith(this.TOKEN_SEMI_COLIN)) {
      normalized = normalized.substring(0, normalized.length - 1);
    }
    return normalized;
  }

  /**
   * Removes Oracle hints from the SQL statement.
   * @param sql
   * @returns
   */
  private clean(sql: string): string {
    const start: number = sql.indexOf(this.TOKEN_ORACLE_HINT_START);
    let end: number = this.NO_INDEX;
    if (start !== this.NO_INDEX) {
      end = sql.indexOf(this.TOKEN_ORACLE_HINT_END);
      if (end !== this.NO_INDEX) {
        const firstHalf: string = sql.substring(0, start);
        const secondHalf: string = sql.substring(end + 2, sql.length);
        return firstHalf.trim() + this.SPACE + secondHalf.trim();
      }
    }
    return sql;
  }

  /**
   * Determines if the current token is part of an Oracle special delete statement.
   * @param currentToken
   * @param tokens
   * @param index
   * @returns
   */
  private isOracleSpecialDelete(currentToken: string, tokens: string[], index: number): boolean {
    index++;
    if (currentToken === this.TOKEN_DELETE) {
      if (this.moreTokens(tokens, index)) {
        let nextToken: string = tokens[index++];
        if (nextToken !== this.KEYWORD_FROM && nextToken !== this.TOKEN_ASTERICK) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * Handles table names in Oracle special delete statements
   * @param currentToken
   * @param tokens
   * @param index
   */
  private handleSpecialOracleSpecialDelete(currentToken: string, tokens: string[], index: number) {
    let tableName: string = tokens[index+1];
    this.considerInclusion(tableName);
  }

  /**
   * Determines if the current token is part of a CREATE INDEX statement.
   * @param currentToken
   * @param tokens
   * @param index
   * @returns
   */
  private isCreateIndex(currentToken: string, tokens: string[], index: number): boolean {
    index++;
    if (currentToken.toLowerCase() === this.TOKEN_CREATE && this.hasIthToken(tokens, index, 3)) {
      let nextToken = tokens[index++];
      if (nextToken.toLowerCase() === this.TOKEN_INDEX) {
        return true;
      }
    }
    return false;
  }

  /**
   * Handles table names in CREATE INDEX statements.
   * @param currentToken
   * @param tokens
   * @param index
   */
  private handleCreateIndex(currentToken: string, tokens: string[], index: number) {
    const tableName: string = tokens[index+4];
    this.considerInclusion(tableName);
  }

  /**
   * checks if there is a token at the specified index.
   * @param tokens
   * @param currentIndex
   * @param tokenNumber
   * @returns
   */
  private hasIthToken(tokens: string[], currentIndex: number, tokenNumber: number): boolean {
    if (this.moreTokens(tokens, currentIndex) && tokens.length > currentIndex + tokenNumber) {
      return true;
    }
    return false;
  }

  /**
   * Determines if the current token should be processed,
   * @param currentToken
   * @returns
   */
  private shouldProcess(currentToken: string): boolean {
    return this.concerned.includes(currentToken.toLowerCase());
  }

  /**
   * Determines if the current token is FROM
   * @param currentToken
   * @returns
   */
  private isFromToken(currentToken: string): boolean {
    return currentToken.toLowerCase() === this.KEYWORD_FROM;
  }

  /**
   * Processes table names following a FROM token.
   * @param tokens
   * @param index
   */
  private processFromToken(tokens: string[], index: number) {
    let currentToken = tokens[index++];
    this.considerInclusion(currentToken);
    let nextToken: string | null = null;
    if (this.moreTokens(tokens, index)) {
      nextToken = tokens[index++];
    }
    if (this.shouldProcessMultipleTables(nextToken)) {
      this.processNonAliasedMultiTables(tokens, index, nextToken);
    } else {
      this.processAliasedMultiTables(tokens, index, currentToken);
    }
  }

  /**
   * Processes multiple tables without aliases.
   * @param tokens
   * @param index
   * @param nextToken
   */
  private processNonAliasedMultiTables(tokens: string[], index: number, nextToken: string | null) {
    while (nextToken === this.TOKEN_COMMA) {
      let currentToken = tokens[index++];
      this.considerInclusion(currentToken);
      if (this.moreTokens(tokens, index)) {
        nextToken = tokens[index++];
      } else {
        break;
      }
    }
  }

  /**
   * Processes multiple tables with aliases.
   * @param tokens
   * @param index
   * @param currentToken
   */
  private processAliasedMultiTables(tokens: string[], index: number, currentToken: string) {
    let nextNextToken: string | null = null;
    if (this.moreTokens(tokens, index)) {
      nextNextToken = tokens[index++];
    }
    if (this.shouldProcessMultipleTables(nextNextToken)) {
      while (this.moreTokens(tokens, index) && nextNextToken === this.TOKEN_COMMA) {
        if (this.moreTokens(tokens, index)) {
          currentToken = tokens[index++];
        }
        if (this.moreTokens(tokens, index)) {
          index++;
        }
        if (this.moreTokens(tokens, index)) {
          nextNextToken = tokens[index++];
        }
        this.considerInclusion(currentToken);
      }
    }
  }

  /**
   * DeterMines if the next token indicates multiple tables(comma-separated).
   * @param nextToken
   * @returns
   */
  private shouldProcessMultipleTables(nextToken: string | null): boolean {
    return nextToken !== null && nextToken === this.TOKEN_COMMA
  }

  /**
   * Checks if there are more tokens to process.
   * @param tokens
   * @param index
   * @returns
   */
  private moreTokens(tokens: string[], index: number): boolean {
    return index < tokens.length;
  }

  /**
   * Considers including the token(table name) in the results.
   * @param token
   */
  private considerInclusion(token: string) {
    if (!this.ignored.includes(token.toLowerCase()) && this.tables.has(token.toLowerCase())) {
      this.tables.set(token.toLowerCase(), token);
    }
  }

  /**
   * returns a set of table names to ensure uniqueness.
   * @returns
   */
  public getTables(): Set<string> {
    return new Set(this.tables.values());
  }
}