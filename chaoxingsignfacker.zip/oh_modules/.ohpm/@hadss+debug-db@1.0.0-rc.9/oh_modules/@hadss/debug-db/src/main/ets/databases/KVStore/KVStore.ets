/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import distributedKVStore from '@ohos.data.distributedKVStore';

/**
 * KVStore class
 */

export class KVStore {
  private kvStore: distributedKVStore.SingleKVStore;

  constructor(kvStore: distributedKVStore.SingleKVStore) {
    this.kvStore = kvStore;
  }

  public get(key: string): Promise<string | number | boolean | Uint8Array> {
    return this.kvStore.get(key);
  }

  public getEntries(keyPrefix?: string): Promise<distributedKVStore.Entry[]> {
    return this.kvStore.getEntries(keyPrefix);
  }

  public put(key: string, value: string | number | boolean | Uint8Array): Promise<void> {
    return this.kvStore.put(key, value);
  }

  public delete(key: string): Promise<void> {
    return this.kvStore.delete(key);
  }
}