/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import dataPreferences from '@ohos.data.preferences';

/**
 * Preferences class
 */

export class Preferences {
  private preferences: dataPreferences.Preferences;

  constructor(preferences: dataPreferences.Preferences) {
    this.preferences = preferences;
  }

  public has(key: string): Promise<boolean> {
    return this.preferences.has(key);
  }

  public hasSync(key: string): boolean {
    return this.preferences.hasSync(key);
  }

  public get(key: string, defValue: dataPreferences.ValueType): Promise<dataPreferences.ValueType> {
    return this.preferences.get(key, defValue);
  }

  public getAll(): Promise<object> {
    return this.preferences.getAll();
  }

  public getAllSync(): object {
    return this.preferences.getAllSync();
  }

  public getSync(key: string, defValue: dataPreferences.ValueType): dataPreferences.ValueType {
    return this.preferences.getSync(key, defValue);
  }

  public put(key: string, value: dataPreferences.ValueType): Promise<void> {
    return this.preferences.put(key, value);
  }

  public putSync(key: string, value: dataPreferences.ValueType): void {
    return this.preferences.putSync(key, value);
  }

  public delete(key: string): Promise<void> {
    return this.preferences.delete(key);
  }

  public deleteSync(key: string): void {
    return this.preferences.deleteSync(key);
  }

  public flush(): Promise<void> {
    return this.preferences.flush();
  }

  public clear(): Promise<void> {
    return this.preferences.clear();
  }

  public clearSync(): void {
    return this.preferences.clearSync();
  }
}