/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import fs from '@ohos.file.fs';
import { HashMap, HashSet } from '@kit.ArkTS';
import { RdbStore } from '../databases/RdbStore/RdbStore';
import { RdbStoreFactory } from '../databases/RdbStore/RdbStoreFactory';
import Logger from '../utils/Logger';
import CommonConstants from '../constants/CommonConstants';
import { RdbStoreHelper } from '../utils/RdbStoreHelper';

let rdbInfoList: RdbInfo[] = [];

export interface RdbInfo {
  context: Context;
  name: string;
  isEncrypted: boolean;
  customDir: string;
}

export class RdbService {
  private static rdbStoreMap: HashMap<string, RdbStore> = new HashMap();
  private static rdbInfoMap: HashMap<string, RdbInfo> = new HashMap();

  public static async deleteRdbStore(rdbName: string) {
    if (RdbService.rdbInfoMap.hasKey(rdbName)) {
      const rdbInfo = RdbService.rdbInfoMap.get(rdbName);
      const delSuccess = await RdbStoreFactory.deleteRdbStore(rdbInfo.context, rdbInfo.name, rdbInfo.customDir);
      if (delSuccess) {
        RdbService.rdbStoreMap.remove(rdbName);
        RdbService.rdbInfoMap.remove(rdbName);
        return true;
      }
    }
    return false;
  }

  public static async getRdbStore(rdbName: string, context?: Context) {
    if (!RdbService.rdbStoreMap.hasKey(rdbName) && context) {
      await RdbService.getAllRdbNameList(context);
    }
    return RdbService.rdbStoreMap.get(rdbName);
  }

  public static async getAllRdbNameList(context: Context, ctxList?: Context[]) {
    const rdbList: string[] = [];

    const appContext = context.getApplicationContext();
    rdbInfoList = [];
    RdbService.scanRdb(appContext);
    for (const rdbInfo of rdbInfoList) {
      const appRdbLabel = `${CommonConstants.APP_PREFIX}${rdbInfo.name}`;
      RdbService.rdbInfoMap.set(appRdbLabel, rdbInfo);
      const rdbStore =
        await RdbStoreFactory.createRdbStore(appContext, rdbInfo.name, rdbInfo.isEncrypted, rdbInfo.customDir);
      if (rdbStore) {
        RdbService.rdbStoreMap.set(appRdbLabel, rdbStore);
        rdbList.push(appRdbLabel)
      }
    }

    rdbInfoList = [];
    RdbService.scanRdb(context);
    for (const rdbInfo of rdbInfoList) {
      RdbService.rdbInfoMap.set(rdbInfo.name, rdbInfo);
      const rdbStore =
        await RdbStoreFactory.createRdbStore(context, rdbInfo.name, rdbInfo.isEncrypted, rdbInfo.customDir);
      if (rdbStore) {
        RdbService.rdbStoreMap.set(rdbInfo.name, rdbStore);
        rdbList.push(rdbInfo.name)
      }
    }
    return rdbList;
  }

  public static async getRdbStoreFile(rdbStoreName: string): Promise<Uint8Array> {
    const rdbInfo = RdbService.rdbInfoMap.get(rdbStoreName);
    let databaseDirPath = `${rdbInfo.context.databaseDir}/rdb`;
    if (rdbInfo.customDir) {
      databaseDirPath = `${databaseDirPath}/${rdbInfo.customDir}`;
    }
    let filePath = `${databaseDirPath}/${rdbInfo.name}`;
    let sourceFilesPath = [filePath, `${filePath}-wal`, `${filePath}-shm`]

    let tempDirPath = `${rdbInfo.context.tempDir}/${rdbInfo.name}`;
    let zipFilePath = `${tempDirPath}/${rdbStoreName}.zip`;

    let fileContent: Uint8Array = new Uint8Array(0);
    try {
      if (fs.accessSync(tempDirPath)) {
        fs.rmdirSync(tempDirPath);
      }
      fs.mkdirSync(tempDirPath);
      await RdbStoreHelper.compressFiles(sourceFilesPath, tempDirPath, zipFilePath);
      let zipFile = await fs.open(zipFilePath, fs.OpenMode.READ_WRITE);
      fileContent = await RdbStoreHelper.getFileUint8Array(zipFile);
    } catch (err) {
      Logger.error(CommonConstants.TAG_RDB_STORE, `Failed to get the byte stream, code is ${err.code}, message is ${err.message}`);
    } finally {
      if (fs.accessSync(tempDirPath)) {
        fs.rmdirSync(tempDirPath);
      }
    }
    return fileContent;
  }

  private static scanRdb(context: Context, scanDir?: string) {
    const rdbDir = `${context.databaseDir}/rdb`;
    const dir = scanDir ?? rdbDir;
    if (!fs.accessSync(dir)) {
      Logger.warn('directory not exist', dir)
      return;
    }
    // 获取目录中的所有文件和子目录
    const fileNameList = fs.listFileSync(dir);
    let dirList: string[] = [];
    let dbFileList: string[] = [];
    let fileSet: HashSet<string> = new HashSet();
    // 遍历目录中的所有文件和子目录
    for (const fileName of fileNameList) {
      const filePath = `${dir}/${fileName}`;

      const stat = fs.lstatSync(filePath);
      if (stat.isDirectory()) {
        dirList.push(filePath);
      } else {
        if (fileName.endsWith('.db')) {
          dbFileList.push(fileName);
        } else {
          fileSet.add(fileName);
        }
      }
    }

    for (const dbFile of dbFileList) {
      if (fileSet.has(`${dbFile}-shm`) && fileSet.has(`${dbFile}-wal`)) {
        const dbName = dbFile.substring(0, dbFile.lastIndexOf('.'));
        const dbFileName = `${dbName}.db`;
        const pubKeyPath = `${dir}/key/${dbName}.pub_key`;
        let customDir = dir.slice(rdbDir.length + 1);
        if (fs.accessSync(pubKeyPath)) {
          Logger.info('found a encrypted rdb', dir, dbName, customDir);
          rdbInfoList.push({
            context,
            name: dbFileName,
            isEncrypted: true,
            customDir
          })
        } else {
          Logger.info('found a rdb', dir, dbName, customDir);
          rdbInfoList.push({
            context,
            name: dbFileName,
            isEncrypted: false,
            customDir
          })
        }
      }
    }

    for (const dirPath of dirList) {
      RdbService.scanRdb(context, dirPath)
    }
  }
}