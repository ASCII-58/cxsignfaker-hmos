/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { common } from '@kit.AbilityKit';
import { HashMap, JSON } from '@kit.ArkTS';
import { IncomingMessage, ServerResponse } from '@ohos/polka';
import { TableDataResponse, UpdateRowResponse, Response } from '../model/ResponseInterfaces';
import { RowDataRequest } from '../model/TableInfoInterfaces';
import { RdbStore } from '../databases/RdbStore/RdbStore';
import { RdbStoreHelper } from '../utils/RdbStoreHelper';
import { PreferencesHelper } from '../utils/PreferencesHelper';
import { PreferencesFactory } from '../databases/Preference/PreferencesFactory';
import { Preferences } from '../databases/Preference/Preferences';
import { KVStore } from '../databases/KVStore/KVStore';
import { KVStoreHelper } from '../utils/KVStoreHelper';
import Logger from '../utils/Logger';
import CommonConstants from '../constants/CommonConstants';
import { RdbService } from './RdbService';
import { KvService } from './KvService';
import { AppStorageHelper } from '../utils/AppStorageHelper';

export class RequestHandler {
  private uiContext: common.UIAbilityContext;
  private appContext: Context;
  private bundleName: string;
  private preferencesFactory: PreferencesFactory;
  private preferencesMap: HashMap<string, Preferences>;
  private selectedDataBase: string = '';

  constructor(context: common.UIAbilityContext) {
    this.uiContext = context;
    this.appContext = context.getApplicationContext();
    this.bundleName = context.abilityInfo.bundleName;
    this.preferencesFactory = new PreferencesFactory();
    this.preferencesMap = new HashMap<string, Preferences>();
  }

  public async getDBListResponse(): Promise<string> {
    let response: Response = {
      rows: [],
      columns: [],
      isSuccessful: false,
      error: '',
      dbVersion: 0
    };

    const rdbNameList = await RdbService.getAllRdbNameList(this.uiContext)!;
    if (rdbNameList) {
      for (let rdbName of rdbNameList) {
        let rdbStoreEntry: string[] = [rdbName, 'false', 'true'];
        response.rows.push(rdbStoreEntry);
      }
    }

    response.rows.push([CommonConstants.ALL_PREFERENCES, 'false', 'true']);
    response.rows.push([CommonConstants.ALL_KV_STORE, 'false', 'true']);
    response.rows.push([CommonConstants.ALL_APP_STORAGE, 'false', 'true']);
    response.isSuccessful = true;
    return JSON.stringify(response);
  }

  public async getTableListResponse(req: IncomingMessage): Promise<string> {
    const databaseName = req.parameters.get('database')?.pop() as string;
    let response: Response = {
      rows: [],
      columns: [],
      isSuccessful: false,
      error: '',
      dbVersion: 0
    };

    if (CommonConstants.ALL_PREFERENCES === databaseName) {
      let preferencesNames = PreferencesHelper.getAllPreferencesName(this.appContext);
      for (let preferencesName of preferencesNames) {
        let preference: Preferences | undefined = await this.getOrCreatePreferences(preferencesName);
        if (preference !== undefined) {
          response.rows.push(`${CommonConstants.APP_PREFIX}${preferencesName}`);
        } else {
          break;
        }
        response.isSuccessful = true;
      }
      preferencesNames = PreferencesHelper.getAllPreferencesName(this.uiContext) || [];
      for (let preferencesName of preferencesNames) {
        let preference: Preferences | undefined = await this.getOrCreatePreferences(preferencesName);
        if (preference !== undefined) {
          response.rows.push(preferencesName);
        } else {
          break;
        }
        response.isSuccessful = true;
      }
      this.selectedDataBase = CommonConstants.ALL_PREFERENCES;
    } else if (CommonConstants.ALL_KV_STORE === databaseName) {
      const kvInfoList = await KvService.getAllStoreId(this.uiContext, this.bundleName)!;
      if (kvInfoList) {
        response.rows.push(...kvInfoList);
      }
      this.selectedDataBase = CommonConstants.ALL_KV_STORE;
    } else if (CommonConstants.ALL_APP_STORAGE === databaseName) {
      response.rows.push(CommonConstants.APP_STORAGE);
      this.selectedDataBase = CommonConstants.ALL_APP_STORAGE;
    } else {
      let rdbStore = await this.getRdbStore(databaseName);
      if (rdbStore !== undefined) {
        response = await RdbStoreHelper.getAllTableName(rdbStore);
      }
      this.selectedDataBase = databaseName;
    }
    return JSON.stringify(response);
  }

  public async getAllDataFromTheTableRespose(req: IncomingMessage): Promise<string> {
    const tableName = req.parameters.get('tableName')?.pop() as string;
    let tableDataResponse: TableDataResponse = {
      tableInfos: undefined,
      rows: undefined,
      isSuccessful: false,
      errorMessage: '',
      isEditable: false,
      isSelectQuery: false
    };

    if (CommonConstants.ALL_PREFERENCES === this.selectedDataBase) {
      let preferences: Preferences | undefined = await this.getOrCreatePreferences(tableName);
      if (preferences !== undefined) {
        tableDataResponse = await PreferencesHelper.getPreferencesData(preferences);
      }
    } else if (CommonConstants.ALL_KV_STORE === this.selectedDataBase) {
      let kvStore: KVStore | undefined = await this.getKVStore(tableName);
      if (kvStore !== undefined) {
        tableDataResponse = await KVStoreHelper.getKVStoreData(kvStore);
      }
    } else if (CommonConstants.ALL_APP_STORAGE === this.selectedDataBase) {
      tableDataResponse = AppStorageHelper.getAppStorageData(tableName);
    } else {
      let rdbStore = await this.getRdbStore(this.selectedDataBase);
      let sql = `SELECT * FROM ${tableName}`;
      if (rdbStore !== undefined) {
        tableDataResponse = await RdbStoreHelper.getTableData(rdbStore, sql, tableName);
      }
    }
    return JSON.stringify(tableDataResponse);
  }

  public async addTableDataAndGetResponse(req: IncomingMessage): Promise<string> {
    let updateRowResponse: UpdateRowResponse = {
      isSuccessful: false
    };
    try {
      const newData = req.parameters.get('addData')?.pop() as string;
      const tableName = req.parameters.get('tableName')?.pop() as string;
      const decodeUpdatedData = decodeURIComponent(newData) as string;
      const rowDataRequests = JSON.parse(decodeUpdatedData) as Array<RowDataRequest>;
      if (CommonConstants.ALL_PREFERENCES === this.selectedDataBase) {
        let preferences: Preferences | undefined = await this.getOrCreatePreferences(tableName);
        if (preferences !== undefined) {
          updateRowResponse = await PreferencesHelper.addOrUpdateRow(preferences, rowDataRequests);
        }
      } else if (CommonConstants.ALL_KV_STORE === this.selectedDataBase) {
        let kvStore: KVStore | undefined = await this.getKVStore(tableName);
        if (kvStore !== undefined) {
          updateRowResponse = await KVStoreHelper.addOrUpdateRow(kvStore, rowDataRequests);
        }
      } else if (CommonConstants.ALL_APP_STORAGE === this.selectedDataBase) {
        updateRowResponse = AppStorageHelper.addOrUpdateRow(rowDataRequests);
      } else {
        let rdbStore = await this.getRdbStore(this.selectedDataBase);
        if (rdbStore !== undefined) {
          updateRowResponse = await RdbStoreHelper.addRow(rdbStore, tableName, rowDataRequests);
        }
      }
    } catch (err) {
      Logger.error(CommonConstants.TAG_DEBUG_DB, `Caught error, code is ${err.code}, message is ${err.message}`);
    }
    return JSON.stringify(updateRowResponse);
  }

  public async updateTableDataAndGetResponse(req: IncomingMessage): Promise<string> {
    let updateRowResponse: UpdateRowResponse = {
      isSuccessful: false
    };
    try {
      const newData = req.parameters.get('updatedData')?.pop() as string;
      const tableName = req.parameters.get('tableName')?.pop() as string;
      const decodeUpdatedData = decodeURIComponent(newData) as string;
      const rowDataRequests = JSON.parse(decodeUpdatedData) as Array<RowDataRequest>;
      if (CommonConstants.ALL_PREFERENCES === this.selectedDataBase) {
        let preferences: Preferences | undefined = await this.getOrCreatePreferences(tableName);
        if (preferences !== undefined) {
          updateRowResponse = await PreferencesHelper.addOrUpdateRow(preferences, rowDataRequests);
        }
      } else if (CommonConstants.ALL_KV_STORE === this.selectedDataBase) {
        let kvStore: KVStore | undefined = await this.getKVStore(tableName);
        if (kvStore !== undefined) {
          updateRowResponse = await KVStoreHelper.addOrUpdateRow(kvStore, rowDataRequests);
        }
      } else if (CommonConstants.ALL_APP_STORAGE === this.selectedDataBase) {
        updateRowResponse = AppStorageHelper.addOrUpdateRow(rowDataRequests);
      } else {
        let rdbStore = await this.getRdbStore(this.selectedDataBase);
        if (rdbStore !== undefined) {
          updateRowResponse = await RdbStoreHelper.updateRow(rdbStore, tableName, rowDataRequests);
        }
      }
    } catch (err) {
      Logger.error(CommonConstants.TAG_DEBUG_DB, `Caught error, code is ${err.code}, message is ${err.message}`);
    }
    return JSON.stringify(updateRowResponse);
  }

  public async deleteTableDataAndGetResponse(req: IncomingMessage): Promise<string> {
    let updateRowResponse: UpdateRowResponse = {
      isSuccessful: false
    };
    try {
      const tableName = req.parameters.get('tableName')?.pop() as string;
      const deleteData = req.parameters.get('deleteData')?.pop() as string;
      const decodeUpdatedData = decodeURIComponent(deleteData) as string;
      const rowDataRequests = JSON.parse(decodeUpdatedData) as Array<RowDataRequest>;
      if (CommonConstants.ALL_PREFERENCES === this.selectedDataBase) {
        let preferences: Preferences | undefined = await this.getOrCreatePreferences(tableName);
        if (preferences !== undefined) {
          updateRowResponse = await PreferencesHelper.deleteRow(preferences, rowDataRequests);
        }
      } else if (CommonConstants.ALL_KV_STORE === this.selectedDataBase) {
        let kvStore: KVStore | undefined = await this.getKVStore(tableName);
        if (kvStore !== undefined) {
          updateRowResponse = await KVStoreHelper.deleteRow(kvStore, rowDataRequests);
        }
      } else if (CommonConstants.ALL_APP_STORAGE === this.selectedDataBase) {
        updateRowResponse = AppStorageHelper.deleteRow(rowDataRequests);
      } else {
        let rdbStore = await this.getRdbStore(this.selectedDataBase);
        if (rdbStore !== undefined) {
          updateRowResponse = await RdbStoreHelper.deleteRow(rdbStore, tableName, rowDataRequests);
        }
      }
    } catch (err) {
      Logger.error(CommonConstants.TAG_DEBUG_DB, `Caught error, code is ${err.code}, message is ${err.message}`);
    }
    return JSON.stringify(updateRowResponse);
  }

  public async executeQueryAndGetResponse(req: IncomingMessage): Promise<string> {
    let data: string | undefined;
    try {
      const queryStatements = req.parameters.get('query')?.pop() as string;
      const decodeQueryStatements = decodeURIComponent(queryStatements) as string;
      if (decodeQueryStatements !== undefined && this.selectedDataBase !== CommonConstants.ALL_PREFERENCES) {
        let statements = decodeQueryStatements.split(';').filter(statement => statement.trim().length > 0);
        let rdbStore = await this.getRdbStore(this.selectedDataBase);
        if (rdbStore !== undefined) {
          for (let statement of statements) {
            let query = statement.trim();
            let operate = query.split(' ')[0].toLowerCase();
            if (operate === 'select' || operate === 'pragma') {
              let tableDataResponse: TableDataResponse = await RdbStoreHelper.getTableData(rdbStore, query);
              data = JSON.stringify(tableDataResponse);
              if (!tableDataResponse.isSuccessful) {
                break;
              }
            } else {
              let tableDataResponse: TableDataResponse = await RdbStoreHelper.exec(rdbStore, query);
              data = JSON.stringify(tableDataResponse);
              if (!tableDataResponse.isSuccessful) {
                break;
              }
            }
          }
        }
      }
    } catch (err) {
      Logger.error(CommonConstants.TAG_DEBUG_DB, `Caught error, code is ${err.code}, message is ${err.message}`);
    }
    if (data === undefined) {
      let response: Response = {
        rows: [],
        columns: [],
        isSuccessful: false,
        error: '',
        dbVersion: 0
      };
      data = JSON.stringify(response);
    }
    return data;
  }

  public async deleteSelectedDataBaseAndGetResponse(): Promise<string> {
    let updateRowResponse: UpdateRowResponse = {
      isSuccessful: false
    };
    if (this.selectedDataBase === '') {
      return JSON.stringify(updateRowResponse);
    }
    let isSuccess: boolean = true;
    if (CommonConstants.ALL_PREFERENCES === this.selectedDataBase) {
      let keysIter = this.preferencesMap.keys();
      let preferencesName: string = keysIter.next().value;
      while (preferencesName !== undefined && this.preferencesMap.hasKey(preferencesName)) {
        isSuccess = await this.preferencesFactory.deletePreferences(this.uiContext, preferencesName);
        if (isSuccess) {
          this.preferencesMap.remove(preferencesName);
          preferencesName = keysIter.next().value;
          updateRowResponse.isSuccessful = isSuccess;
        }
      }
    } else {
      updateRowResponse.isSuccessful = false;
      isSuccess = await RdbService.deleteRdbStore(this.selectedDataBase);
      if (isSuccess) {
        updateRowResponse.isSuccessful = isSuccess;
      }
    }
    return JSON.stringify(updateRowResponse);
  }

  public async getDBFile(res: ServerResponse): Promise<Uint8Array> {
    const bytes: Uint8Array = await RdbService.getRdbStoreFile(this.selectedDataBase);
    res.writeHead(200, {
      'Content-Type': 'application/octet-stream',
      'Content-Disposition': 'attachment; filename=' + this.selectedDataBase + '.zip'
    });
    return bytes;
  }

  private async getOrCreatePreferences(preferencesName: string): Promise<Preferences | undefined> {
    let preferences: Preferences | undefined;
    if (this.preferencesMap.hasKey(preferencesName)) {
      return this.preferencesMap.get(preferencesName);
    }
    if (preferencesName.startsWith(CommonConstants.APP_PREFIX)) {
      preferences = await this.preferencesFactory.createPreferences(this.appContext,
        preferencesName.substring(CommonConstants.APP_PREFIX.length));
    } else {
      preferences = await this.preferencesFactory.createPreferences(this.uiContext, preferencesName);
    }
    if (preferences) {
      this.preferencesMap.set(preferencesName, preferences);
    }
    return preferences;
  }

  private async getKVStore(kvStoreName: string): Promise<KVStore | undefined> {
    return KvService.getKvStore(kvStoreName, this.bundleName);
  }

  private async getRdbStore(rdbStoreName: string): Promise<RdbStore | undefined> {
    return RdbService.getRdbStore(rdbStoreName, this.uiContext);
  }
}