/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { bundleManager } from '@kit.AbilityKit';
import { common } from '@kit.AbilityKit'
import Logger from './utils/Logger';
import { DebugDBConfig, IDebugDBConfig } from './config/DebugDBConfig';
import { AppServer } from './server/AppServer'

export class DebugDB {
  private static appServer: AppServer;
  private static isDebugMode: boolean = false;

  public static async initialize(context: common.UIAbilityContext, config?: IDebugDBConfig) {
    const bundleFlags = bundleManager.BundleFlag.GET_BUNDLE_INFO_WITH_APPLICATION;
    const bundleInfo = await bundleManager.getBundleInfoForSelf(bundleFlags);
    const appInfo = bundleInfo?.appInfo;
    if (appInfo) {
      Logger.debug('appInfo', `debug = ${appInfo.debug}, appProvisionType = ${appInfo.appProvisionType}`);
      DebugDB.isDebugMode = appInfo.debug || appInfo.appProvisionType === 'debug';
    }

    if (!DebugDB.isDebugMode) {
      Logger.info('Application is not in debug mode, debug-db is disabled by default.');
      return;
    }
    DebugDB.appServer = new AppServer(context);
    DebugDBConfig.setDebugDBConfig(config);
    DebugDB.appServer.init();
  }

  public static start(): boolean {
    if (!DebugDB.isDebugMode) {
      return false;
    }
    return DebugDB.appServer.start();
  }

  public static stop(): boolean {
    if (!DebugDB.isDebugMode) {
      return true;
    }
    return DebugDB.appServer.stop();
  }

  public static async getDebugDBAddress(): Promise<string> {
    if (!DebugDB.isDebugMode) {
      return '';
    }
    return await DebugDB.appServer.getDebugDBAddress();
  }
}
