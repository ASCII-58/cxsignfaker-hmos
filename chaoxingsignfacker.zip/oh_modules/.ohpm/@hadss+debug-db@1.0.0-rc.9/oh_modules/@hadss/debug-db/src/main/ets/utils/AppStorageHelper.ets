/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { TableDataResponse, UpdateRowResponse } from '../model/ResponseInterfaces';
import Logger from './Logger';
import DataTypeConstants from '../constants/DataTypeConstants';
import CommonConstants from '../constants/CommonConstants';
import { CommonValueType, TableInfo, CommonColumnData, RowDataRequest } from '../model/TableInfoInterfaces';
import { CommonUtil } from './CommonUtil';

export class AppStorageHelper {
  public static getAppStorageData(tableName: string): TableDataResponse {
    let tableDataResponse: TableDataResponse = AppStorageHelper.initTableDataResponse();

    let keys: string[] = AppStorageHelper.getAppStorageKeys(tableName);

    try {
      for (let key of keys) {
        let row = new Array<CommonValueType>();
        let KeyColumnData: CommonColumnData = {
          dataType: DataTypeConstants.TEXT,
          value: key
        };
        row.push(KeyColumnData);
        let valueColumnData: CommonColumnData = {
          dataType: '',
          value: undefined
        };
        let value = AppStorageHelper.getAppStorageValue(key);
        if (value) {
          valueColumnData.value = CommonUtil.dataStringify(value);
          valueColumnData.dataType = AppStorageHelper.getDataType(value);
        }
        row.push(valueColumnData);
        tableDataResponse.rows!.push(row);
      }
    } catch (err) {
      Logger.error(CommonConstants.TAG_APP_STORAGE,
        `Get appStorage data failed, code is ${err.code}, message is ${err.message}`);
      tableDataResponse.errorMessage = err.message;
      tableDataResponse.isSuccessful = false;
    }
    return tableDataResponse;
  }

  private static getDataType(value: CommonValueType) {
    let dataType = DataTypeConstants.TEXT;
    switch (typeof value) {
      case DataTypeConstants.BOOLEAN:
        dataType = DataTypeConstants.BOOLEAN;
        break;
      case DataTypeConstants.NUMBER:
        if (Number.isInteger(value)) {
          dataType = DataTypeConstants.INTEGER;
        } else {
          dataType = DataTypeConstants.REAL;
        }
        break;
      case DataTypeConstants.STRING:
        dataType = DataTypeConstants.TEXT;
        break;
      default:
        dataType = DataTypeConstants.TEXT;
    }
    return dataType;
  }

  private static initTableDataResponse() {
    let tableDataResponse: TableDataResponse = {
      tableInfos: undefined,
      rows: undefined,
      isSuccessful: true,
      errorMessage: '',
      isEditable: true,
      isSelectQuery: true
    };
    let keyInfo: TableInfo = {
      title: CommonConstants.KEY,
      isPrimary: true
    };
    let valueInfo: TableInfo = {
      title: CommonConstants.VALUE,
      isPrimary: false
    };
    tableDataResponse.tableInfos = new Array<TableInfo>();
    tableDataResponse.tableInfos.push(keyInfo);
    tableDataResponse.tableInfos.push(valueInfo);
    tableDataResponse.rows = new Array();
    return tableDataResponse;
  }

  private static getAppStorageValue(key: string): CommonValueType {
    return AppStorage.get(key) as CommonValueType;
  }

  private static getAppStorageKeys(tableName: string) {
    let keys: string[] = [];
    if (CommonConstants.APP_STORAGE !== tableName) {
      return keys;
    }
    for (const key of AppStorage.keys()) {
      keys.push(key);
    }
    return keys.sort();
  }

  public static addOrUpdateRow(rowDataRequests: Array<RowDataRequest>): UpdateRowResponse {
    let updateRowResponse: UpdateRowResponse = {
      isSuccessful: false
    };
    if (rowDataRequests === undefined) {
      Logger.warn('AppStorage:addOrUpdateRow, rowDataRequests is undefined');
      return updateRowResponse;
    }

    try {
      let key = rowDataRequests[0].value as string | undefined;
      let value = rowDataRequests[1].value as CommonValueType;
      if (key && value) {
        AppStorage.setOrCreate(key, value);
        updateRowResponse.isSuccessful = true;
      } else {
        Logger.warn('AppStorage:addOrUpdateRow, key or value is invalid');
      }
    } catch (err) {
      Logger.error(`AppStorage:addOrUpdateRow, code: ${err.code}, messagez: ${err.message}`);
    }
    return updateRowResponse;
  }

  public static deleteRow(rowDataRequests: Array<RowDataRequest>): UpdateRowResponse {
    let updateRowResponse: UpdateRowResponse = {
      isSuccessful: false
    };
    if (rowDataRequests === undefined) {
      Logger.warn('AppStorage:deleteRow, rowDataRequests is undefined');
      return updateRowResponse;
    }

    try {
      let key = rowDataRequests[0].value as string | undefined;
      if (key) {
        AppStorage.delete(key);
        updateRowResponse.isSuccessful = true;
      } else {
        Logger.warn('AppStorage:deleteRow, key is invalid');
      }
    } catch (err) {
      Logger.error(CommonConstants.TAG_PREFERENCE, `Delete failed, code is ${err.code}, message is ${err.message}`);
    }
    return updateRowResponse;
  }
}