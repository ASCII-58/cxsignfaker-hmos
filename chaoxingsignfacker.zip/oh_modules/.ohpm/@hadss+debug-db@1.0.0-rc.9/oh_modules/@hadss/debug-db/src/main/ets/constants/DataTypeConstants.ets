/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

export default class DataTypeConstants {
  static readonly UNDEFINED: string = 'undefined';
  static readonly BOOLEAN: string = 'boolean';
  static readonly NUMBER: string = 'number';
  static readonly NUM: string = 'num';
  static readonly NUM_FMT: string = 'num-fmt';
  static readonly INTEGER: string = 'integer';
  static readonly FLOAT: string = 'float';
  static readonly DOUBLE: string = 'float';
  static readonly REAL: string = 'real';
  static readonly BIGINT: string = 'bigint';
  static readonly BLOB: string = 'blob';
  static readonly TEXT: string = 'text';
  static readonly STRING: string = 'string';
  static readonly SYMBOL: string = 'symbol';
  static readonly FUNCTION: string = 'function';
  static readonly OBJECT: string = 'object';
}