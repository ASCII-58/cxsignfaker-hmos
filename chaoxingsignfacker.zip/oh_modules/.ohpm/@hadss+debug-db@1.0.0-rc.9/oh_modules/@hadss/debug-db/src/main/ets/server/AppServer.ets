/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import polka, { IncomingMessage, ServerResponse, statik, Request, Polka, NextFunction } from '@ohos/polka';
import { common } from '@kit.AbilityKit';
import { buffer } from '@kit.ArkTS';
import { resourceManager } from '@kit.LocalizationKit';
import { RequestHandler } from './RequestHandler';
import util from '@ohos.util';
import wifiManager from '@ohos.wifiManager';
import Logger from '../utils/Logger';
import CommonConstants from '../constants/CommonConstants';
import { DebugDBConfig } from '../config/DebugDBConfig';

export class AppServer {
  private appServer: Polka<Request>;
  private port: number;
  private context: common.UIAbilityContext;
  private assetsManager: resourceManager.ResourceManager;
  private textEncoder: util.TextEncoder;
  private requestHandler: RequestHandler;

  constructor(context: common.UIAbilityContext) {
    this.appServer = polka();
    this.port = CommonConstants.SERVER_PORT;
    this.context = context;
    this.requestHandler = new RequestHandler(this.context);
    this.assetsManager = context.resourceManager;
    this.textEncoder = new util.TextEncoder('utf-8');
  }

  public init() {
    this.port = DebugDBConfig.port;
    this.appServer = this.appServer
      .get('/*', (req: IncomingMessage, res: ServerResponse, next: NextFunction) => {
        let fileName: string = req.path.split('/').pop() || '';
        fileName = `debug_db/${fileName}`;
        let fileExtension = 'NOT_EXIST';
        if (fileName.includes('.')) {
          fileExtension = `.${fileName.split('.').pop()}`;
        }
        if (!CommonConstants.STATIC_EXTENSIONS.includes(fileExtension)) {
          next();
          return;
        }

        try {
          const fileContent = this.assetsManager.getRawFileContentSync(fileName);
          if (!fileContent) {
            Logger.warn(CommonConstants.TAG_SERVER, `content of file:${fileName} is empty`);
          }
          let buf = buffer.from(fileContent);
          res.setHeader('Content-Type', statik.mime.getType(fileExtension) || 'application/octet-stream');
          res.end(buf.buffer);
        } catch (err) {
          let errMsg = `Failed to load file: ${fileName}, Error:${err.code}, ${err.message}`;
          const moduleName = this.context.currentHapModuleInfo.name;
          const rawFileList = this.assetsManager.getRawFileListSync('');
          errMsg += `\nExtInfo: moduleName=${moduleName}, rawFileList=${rawFileList}`;
          Logger.error(CommonConstants.TAG_SERVER, errMsg);
          res.writeHead(404);
          res.end(errMsg);
        }
      })
      .get('/getDbList', async (_req: IncomingMessage, res: ServerResponse) => {
        const response = await this.requestHandler.getDBListResponse();
        const bytes = this.textEncoder.encodeInto(response);
        res.writeHead(200, {
          'Content-Type': 'application/octet-stream',
          'Content-Length': bytes.byteLength
        });
        res.end(bytes);
      })
      .get('/getTableList', async (req: IncomingMessage, res: ServerResponse) => {
        const response = await this.requestHandler.getTableListResponse(req);
        const bytes = this.textEncoder.encodeInto(response);
        res.writeHead(200, {
          'Content-Type': 'application/octet-stream',
          'Content-Length': bytes.byteLength
        });
        res.end(bytes);
      })
      .get('/getALlDataFromTheTable', async (req: IncomingMessage, res: ServerResponse) => {
        const response = await this.requestHandler.getAllDataFromTheTableRespose(req);
        const bytes = this.textEncoder.encodeInto(response);
        res.writeHead(200, {
          'Content-Type': 'application/octet-stream',
          'Content-Length': bytes.byteLength
        })
        res.end(bytes);
      })
      .get('/addTableData', async (req: IncomingMessage, res: ServerResponse) => {
        const response = await this.requestHandler.addTableDataAndGetResponse(req);
        const bytes = this.textEncoder.encodeInto(response);
        res.writeHead(200, {
          'Content-Type': 'application/octet-stream',
          'Content-Length': bytes.byteLength
        });
        res.end(bytes);
      })
      .get('/updateTableData', async (req: IncomingMessage, res: ServerResponse) => {
        const response = await this.requestHandler.updateTableDataAndGetResponse(req);
        const bytes = this.textEncoder.encodeInto(response);
        res.writeHead(200, {
          'Content-Type': 'application/octet-stream',
          'Content-Length': bytes.byteLength
        })
        res.end(bytes);
      })
      .get('/deleteTableData', async (req: IncomingMessage, res: ServerResponse) => {
        const response = await this.requestHandler.deleteTableDataAndGetResponse(req);
        const bytes = this.textEncoder.encodeInto(response);
        res.writeHead(200, {
          'Content-Type': 'application/octet-stream',
          'Content-Length': bytes.byteLength
        })
        res.end(bytes);
      })
      .get('/query', async (req: IncomingMessage, res: ServerResponse) => {
        const response = await this.requestHandler.executeQueryAndGetResponse(req);
        const bytes = this.textEncoder.encodeInto(response);
        res.writeHead(200, {
          'Content-Type': 'application/octet-stream',
          'Content-Length': bytes.byteLength
        })
        res.end(bytes);
      })
      .get('/deleteDb', async (_req: IncomingMessage, res: ServerResponse) => {
        const response = await this.requestHandler.deleteSelectedDataBaseAndGetResponse();
        const bytes = this.textEncoder.encodeInto(response);
        res.writeHead(200, {
          'Content-Type': 'application/octet-stream',
          'Content-Length': bytes.byteLength
        });
        res.end(bytes);
      })
      .get('/downloadDb', async (_req: IncomingMessage, res: ServerResponse) => {
        const bytes = await this.requestHandler.getDBFile(res);
        res.end(bytes);
      })
    if (DebugDBConfig.shouldStart) {
      this.start();
    }
  }

  public start() {
    if (!this.appServer.server) {
      this.appServer = this.appServer.listen(this.port, '0.0.0.0', (message) => {
        Logger.info(CommonConstants.TAG_SERVER, `listen: ${message}`);
        this.getDebugDBAddress();
      });
      return true;
    }

    try {
      this.appServer.server?.start();
      Logger.info(CommonConstants.TAG_SERVER, `Server started sucessful.`);
      return true;
    } catch (err) {
      Logger.error(CommonConstants.TAG_SERVER, `Server failed to start.`);
    }
    return false;
  }

  public stop() {
    try {
      this.appServer.server?.stop();
      Logger.info(CommonConstants.TAG_SERVER, `Server closed sucessful.`);
      return true;
    } catch (err) {
      Logger.error(CommonConstants.TAG_SERVER, `Server failed to stop.`);
    }
    return false;
  }

  /**
   * 已连接wifi，使用wifi的ip；
   * 否则，使用本地ip。
   * @return
   */
  public async getDebugDBAddress(): Promise<string> {
    try {
      const info = await wifiManager.getLinkedInfo();
      const ipAddress = this.resolveIPAddress(info.ipAddress);
      const address = `${ipAddress}:${this.port}`
      Logger.info(CommonConstants.TAG_DEBUG_DB, `You can access DebugDB through http://${address}/index.html`);
      return address;
    } catch (err) {
      Logger.error(CommonConstants.TAG_DEBUG_DB,
        `Unable to get network information, code: ${err.code}, message: ${err.message}.`);
      // 热点地址
      const apAddress = `192.168.43.1:${this.port}`;
      const apUrl = `http://${apAddress}/index.html`;
      // 本地地址
      const localAddress = `127.0.0.1:${this.port}`;
      const localUrl = `http://${localAddress}/index.html`;
      Logger.warn(CommonConstants.TAG_DEBUG_DB, `Try to access DebugDB through ${apUrl} or ${localUrl}`);
      // todo if 开启热点 return ApAddress, 暂未找到API来判断是否开启热点
      return localAddress;
    }
  }

  public resolveIPAddress(ip: number): string {
    if (ip < 0 || ip > 0xFFFFFFFF) {
      return '';
    }
    return (ip >>> 24) + '.' + (ip >> 16 & 0xFF) + '.' + (ip >> 8 & 0xFF) + '.' + (ip & 0xFF);
  }
}