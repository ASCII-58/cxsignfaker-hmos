/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { HashMap } from '@kit.ArkTS';
import { distributedKVStore } from '@kit.ArkData';
import { Context } from '@kit.AbilityKit';
import { KVStoreFactory } from '../databases/KVStore/KVStoreFactory';

export interface KvInfo {
  context: Context;
  storeId: string;
  isEncrypted: boolean;
}

export class KvService {
  private static kvInfoMap: HashMap<string, KvInfo> = new HashMap();

  public static async getKvStore(storeName: string, bundleName: string) {
    const kvInfo = KvService.kvInfoMap.get(storeName);
    const kvManager = KvService.createKVManager(kvInfo.context, bundleName);

    // 暴力尝试
    let kvStore = await KVStoreFactory.getKVStore(kvManager, storeName, false);
    if (kvStore) {
      return kvStore;
    }
    kvStore = await KVStoreFactory.getKVStore(kvManager, storeName, true);
    return kvStore;
  }

  public static async getAllStoreId(context: Context, bundleName: string) {
    KvService.kvInfoMap.clear();
    const kvManager = KvService.createKVManager(context, bundleName);
    // todo 只需要一个context就可以把其它context（如ApplicationContext）下storeId全部查询出来
    let kvStoreIdList: string[] = await kvManager.getAllKVStoreId(bundleName);
    for (const kvStoreId of kvStoreIdList) {
      // 可以考虑扫描文件目录来判断kvstore是否是加密的
      KvService.kvInfoMap.set(kvStoreId, { context: context, storeId: kvStoreId, isEncrypted: false });
    }
    return kvStoreIdList;
  }

  private static createKVManager(context: Context, bundleName: string) {
    const kvManagerConfig: distributedKVStore.KVManagerConfig = {
      context: context,
      bundleName: bundleName
    };
    return distributedKVStore.createKVManager(kvManagerConfig);
  }
}